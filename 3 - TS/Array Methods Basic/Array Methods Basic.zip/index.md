1. Use the numbersArray for these questions:
   1.1. Define the array type and use the declaration.
   1.2. Check the length of the array
   1.3. Return the last index of the array - use at least 3 options on how we can return it.
   1.4. Return all the numbers that are bigger than 10.
   1.5. Return all the numbers that are divisible by 2.
   1.6. Return all the odd numbers.
   1.7. Return a new array (use numbersArray) with all the numbers multiplied by 4.
   1.8. Return a new array (use numbersArray) where all the numbers will type string (instead of a number)
   1.9. Return a new array (use numbersArray) where all numbers get key - example : [{key: number}, {key: number}]
   1.10. Return descending sorted array.

Important:

1. To solve use array methods.
2. Use console.log() to show the answers.
3. Each answer will running in function (regular or arrow).
